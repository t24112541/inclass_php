<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="registercontroller.php" method="POST" enctype="multipart/form-data">
		<input type="text" name="u_id" placeholder="student id"><p>
		<input type="text" name="u_name" placeholder="name"><p>
		<input type="text" name="u_username" placeholder="username"><p>
		<input type="text" name="u_password" placeholder="password"><p>
		<input type="file" name="u_img_1" ><p>
		<input type="file" name="u_img_2" ><p>
		<input type="submit" name="btn_regist" value="register"><p>
		<a href="index.php">back</a>
	</form>
</body>
</html>
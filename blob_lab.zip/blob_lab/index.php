
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<center>
		<form action="logincontroller.php" method="POST">
			<input type="text" name="u_username" placeholder="username" required><br>
			<input type="password" name="u_password" placeholder="password" required><br>
			<input type="submit" name="btn_login" value="login"><p>
		</form>
		<a href="register.php">register</a>
	</center>
</body>
</html>
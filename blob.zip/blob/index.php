
<?php 

// $html = file_get_contents('http://localhost/charn/blob/dataQuerySelector.html');
$html='<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table border="1">
		<tr>
			<th>รหัส</th>
			<th>ชื่อ</th>
			<th>รูป</th>
		</tr>

		<tr>
			<td><a href="convert_binary.php?img_id=</td>
			<td><img src=""></td>		
		</tr>
	</table>
</body>
</html>';

$dom = new DOMDocument();
$dom->loadHTMLFile($html);

foreach ($elements as $element) {
	// echo "<p>". $element->nodeName. ": ";
}
// echo "<pre>";
// print_r($dom);
// echo "</pre>";
?>

